#ifndef GPIO_H
#define GPIO_H

#include "stm32l476xx.h"

void InitGPIO();

#endif